
import React from "react";
const letweknow = () => 
{
    console.log("Hello World!")
}
function Callit()
{
    return(<div>
        <button onClick={letweknow}>Array</button>
    </div>)
}
export default Callit;
