import React from 'react';
const wel = () =>
{
  return (
    <div>
      <h1>Hello, World!</h1>
    </div>
  )
}
export default wel;
