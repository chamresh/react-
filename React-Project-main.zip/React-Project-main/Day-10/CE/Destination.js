import React from 'react';

const Destination = () => {
    return (
        <div>
            <h2>Destination Page</h2>
            <p>Explore different travel destinations.</p>
        </div>
    );
};

export default Destination;
