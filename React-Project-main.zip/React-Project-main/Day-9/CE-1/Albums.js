import React from 'react';

const Albums = () => {
    return (
        <div>
            <h2>Albums</h2>
            <ul>
                <li>Album A - John Doe</li>
                <li>Album B - Jane Smith</li>
                <li>Album C - Bob Johnson</li>
            </ul>
        </div>
    );
};

export default Albums;
