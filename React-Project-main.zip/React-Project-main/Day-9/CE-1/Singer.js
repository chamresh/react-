import React from 'react';

const Singers = () => {
    return (
        <div>
            <h2>Singers</h2>
            <ul>
                <li>John Doe - 1990</li>
                <li>Jane Smith - 1985</li>
                <li>Bob Johnson - 2000</li>
            </ul>
        </div>
    );
};

export default Singers;
